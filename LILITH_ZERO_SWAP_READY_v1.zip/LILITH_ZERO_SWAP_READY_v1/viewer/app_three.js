import * as THREE from "https://unpkg.com/three@0.160.0/build/three.module.js";
import { OrbitControls } from "https://unpkg.com/three@0.160.0/examples/jsm/controls/OrbitControls.js";
import { GLTFLoader } from "https://unpkg.com/three@0.160.0/examples/jsm/loaders/GLTFLoader.js";

const HERO_PATH = "./assets/hero/lilith_character.glb";
const canvas = document.getElementById("heroCanvas");
const statusEl = document.getElementById("status");
const runtimeMode = document.getElementById("runtimeMode");
const mode = document.getElementById("mode");

if (!(location.protocol === "http:" || location.protocol === "https:")) {
  runtimeMode.textContent = "Safe Canvas (content://)";
  mode.textContent = "SAFE CANVAS MODE";
  throw new Error("content protocol: keep fallback renderer");
}

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setClearColor("#07080d");
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.12;

const scene = new THREE.Scene();
scene.background = new THREE.Color("#07080d");

const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
camera.position.set(0, 1.0, 4.2);

const controls = new OrbitControls(camera, canvas);
controls.target.set(0, 0.55, 0);
controls.enablePan = false;
controls.enableDamping = true;
controls.autoRotate = true;
controls.autoRotateSpeed = 0.35;
controls.minDistance = 1.2;
controls.maxDistance = 6.0;

scene.add(new THREE.HemisphereLight(0xffffff, 0x202035, 1.15));
const key = new THREE.DirectionalLight(0xffffff, 3.2);
key.position.set(4, 6, 5);
scene.add(key);
const rim = new THREE.DirectionalLight(0x8d6dff, 2.0);
rim.position.set(-4, 3, -4);
scene.add(rim);

let hero = null;

function applyHeroMaterials(root) {
  root.traverse((node) => {
    if (!node.isMesh) return;
    const n = node.name || "";
    if (n.includes("GEM_CORE") || n.includes("EYE_") || n.includes("WEAPON_VIOLET")) {
      node.material = new THREE.MeshStandardMaterial({ color:"#9364FF", emissive:"#6D31FF", emissiveIntensity:2.0, roughness:0.08 });
    } else if (n.includes("SEAL_NETWORK")) {
      node.material = new THREE.MeshStandardMaterial({ color:"#6D31FF", emissive:"#6D31FF", emissiveIntensity:1.4, roughness:0.25 });
    } else if (n.includes("GOLD")) {
      node.material = new THREE.MeshStandardMaterial({ color:"#A67C32", metalness:1.0, roughness:0.25 });
    } else if (n.includes("ARMOR")) {
      node.material = new THREE.MeshStandardMaterial({ color:"#111214", metalness:0.95, roughness:0.18 });
    } else if (n.includes("HAIR")) {
      node.material = new THREE.MeshStandardMaterial({ color:"#ECEDEF", metalness:0.05, roughness:0.28, side:THREE.DoubleSide });
    } else {
      node.material = new THREE.MeshStandardMaterial({ color:"#F2E5DF", roughness:0.52 });
    }
  });
}

new GLTFLoader().load(HERO_PATH, (gltf) => {
  window.__LILITH_FALLBACK_STOP__?.();
  hero = gltf.scene;
  hero.name = "LILITH_ZERO_HERO_ASSET";
  applyHeroMaterials(hero);
  scene.add(hero);
  statusEl.textContent = "REAL GLB LOADED";
  runtimeMode.textContent = "Three.js GLB Runtime";
  mode.textContent = "GLB RUNTIME MODE";
}, (event) => {
  if (event.total) statusEl.textContent = `GLB LOADING ${Math.round(event.loaded / event.total * 100)}%`;
  else statusEl.textContent = "GLB LOADING";
}, () => {
  statusEl.textContent = "GLB FAILED · FALLBACK ACTIVE";
  runtimeMode.textContent = "Safe Canvas";
  mode.textContent = "SAFE CANVAS MODE";
});

function resize() {
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, matchMedia("(max-width:800px)").matches ? 1.25 : 2));
  renderer.setSize(w, h, false);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}

function loop(ms) {
  if (!hero) { requestAnimationFrame(loop); return; }
  resize();
  const t = ms * 0.001;
  hero.position.y = Math.sin(t * 1.45) * 0.018;
  hero.traverse((node) => {
    if (!node.material) return;
    if (node.name.includes("GEM_CORE")) node.material.emissiveIntensity = 2.1 + Math.sin(t * 2.2) * 0.75;
    if (node.name.includes("SEAL_NETWORK")) node.material.emissiveIntensity = 1.45 + Math.sin(t * 2.8) * 0.55;
  });
  controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
