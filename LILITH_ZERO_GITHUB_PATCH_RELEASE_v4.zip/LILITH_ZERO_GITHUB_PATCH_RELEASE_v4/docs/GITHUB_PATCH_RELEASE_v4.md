# LILITH ZERO GitHub Patch Release v4

content://는 Safe Canvas, http/https는 Three.js GLB Runtime으로 동작합니다.
