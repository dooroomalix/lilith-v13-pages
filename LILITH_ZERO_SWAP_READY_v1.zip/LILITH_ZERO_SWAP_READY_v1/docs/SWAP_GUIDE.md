# GLB 교체 가이드

교체 파일:

```text
assets/hero/lilith_character.glb
```

GitHub에서 기존 프록시 GLB를 이 파일로 덮어쓰면 됩니다.

추가 패치:

```text
viewer/app_three.js
```

이 파일도 같이 업로드하면 GLB 경로와 재질 매핑이 고정됩니다.
