# LILITH ZERO SWAP READY v1

GitHub에서 아래 파일을 교체하세요.

```text
assets/hero/lilith_character.glb
viewer/app_three.js
```

제공 GLB:

```text
assets/hero/lilith_character.glb
assets/hero/lilith_character_artist_swap_v1.glb
```

Stats:

```text
Triangles: 125,240
Hair cards: 76
```
