# LILITH ZERO · GitHub Patch Release v4

content:// → Safe Canvas
http/https → Three.js GLB Runtime
GLB 실패 → Safe Canvas 유지
